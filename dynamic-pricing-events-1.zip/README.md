# 🎟️ Dynamic Pricing Model for Local Events & Experiences

## Objective
Build a dynamic pricing system using real-time demand, competitor pricing, and user sentiment.

## Structure
- `scripts/`: Scraper, preprocessing, and ML models
- `dashboard/`: Streamlit dashboard
- `simulation/`: Revenue simulation
- `notebooks/`: Jupyter notebooks for EDA
- `data/`: Raw and processed datasets
